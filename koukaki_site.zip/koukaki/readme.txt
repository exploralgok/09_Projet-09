Koukaki - Fleurs d'oranger et chats errants
===================================================
Vous trouverez ci-joint une copie du site actuel de Koukaki. Pour installer le site : 

1. Installer une nouvelle instance locale de WordPress
2. Installer l'extension all-in-one-wp-migration
3. Importer le fichier fournis

L'utilisateur et le mot de passe sont : admin / admin

Si vous désirez faire des modifications sur le thème (pour test), dirigez vous dans le dossier du thème et entrez les commandes suivantes dans le terminal : 

`npm install` 
`composer install` 

Faire les modifications demandées dans le thème enfant. 